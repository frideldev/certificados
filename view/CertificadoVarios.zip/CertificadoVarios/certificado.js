function GenerarCertificado(data) {
    var canvas = document.createElement('canvas');
    canvas.width = 900;
    canvas.height = 650;
    var ctx = canvas.getContext('2d');
    var image = new Image();
    var imageqr = new Image();
    var imageusu = new Image();
    image.src = data[0].cur_img;
    imageqr.src = "../../public/qr/" + data[0].curd_id + ".png";
    imageusu.src = data[0].usu_img;
    /* Dimensionamos y seleccionamos imagen */
    var doc = new jsPDF('l', 'px', 'letter');
    image.onload = function () {
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        imageqr.onload = function () {
            ctx.drawImage(imageqr, 15, 500, 100, 100);
            imageusu.onload = function () {
                data.map((datos, index) => {
                    ctx.drawImage(imageusu, 739, 100, 100, 100);
                    var imageData=canvas.toDataURL('image/png');
                    if (index !== 0) {
                        doc.addPage('letter', 'l');
                    }
                    doc.addImage(imageData, "PNG", 30, 15);
                });
                doc.save('Certificado2.pdf');
            };
        };
    };
}
$(document).ready(function () {
    var cur_id = getUrlParameter('cur_id');
    $.post("../../controller/usuario.php?op=mostrar_curso_detalle_varios", { cur_id: cur_id }, function (data) {
        data = JSON.parse(data);
        GenerarCertificado(data);
    });
});


var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};
